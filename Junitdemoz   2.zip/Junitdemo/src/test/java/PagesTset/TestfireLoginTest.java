package PagesTset;

import Pages.TestfireHomePage;
import Pages.TestfireLogin;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class TestfireLoginTest {
    WebDriver driver ;
    TestfireLogin objLogin;
    TestfireHomePage objHomePage;

    @BeforeTest
    public void setup(){

        System.setProperty("webdriver.chrome.driver", "D:/QMDownload/Driver/chromedriverV78.0.3904.70.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://www.testfire.net/login.jsp");
    }



    @Test(priority=0)
    public void test_Home_Page_Appear_Correct(){
        //Create Login Page object
        objLogin = new TestfireLogin(driver);
        //Verify login page title
        String loginPageTitle = objLogin.getLoginTitle();
        //System.out.println(loginPageTitle);
        Assert.assertTrue(loginPageTitle.toLowerCase().contains("Online Banking Login"));
        //login to application
        objLogin.LoginTotestfire("admin", "admin");
        // go the next page
        objHomePage = new TestfireHomePage(driver);
        //Verify home page
        Assert.assertTrue(objHomePage.getHomePageCongratulations().toLowerCase().contains("Congratulations!"));
    }

}
